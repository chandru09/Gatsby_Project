document.addEventListener("DOMContentLoaded", function () {
  const userEmail = localStorage.getItem("loggedInUser");
  console.log("UE", userEmail);
  if (userEmail) {
    window.parent.document.getElementById("userEmail").textContent = userEmail;
  } else {
    // If the email is not found in local storage, redirect to the login page
    window.location.href = "login.html";
  }
});
