
document.addEventListener("DOMContentLoaded", () => {
   // Function to open the delete confirmation modal
   function openDeleteModal(email) {
    const deleteModal = document.getElementById("deleteModal");
    deleteModal.style.display = "block";

    const confirmDeleteButton = document.getElementById("confirmDelete");
    const cancelDeleteButton = document.getElementById("cancelDelete");

    confirmDeleteButton.onclick = () => {
      deleteUser(email);
    };

    cancelDeleteButton.onclick = () => {
      closeModal();
    };
  }

  // Function to close the delete confirmation modal
  function closeModal() {
    const deleteModal = document.getElementById("deleteModal");
    deleteModal.style.display = "none";
  }
  // Function to get registered users from local storage
  function getRegisteredUsers() {
    const users = JSON.parse(localStorage.getItem("Users")) || [];
    return users;
  }

  // Function to delete a user
  function deleteUser(email) {
    const users = getRegisteredUsers();
    const updatedUsers = users.filter((user) => user.Email !== email);
    localStorage.setItem("Users", JSON.stringify(updatedUsers));
    populateUserTable();
    closeModal();
  }
 

  // Function to populate the table with registered user data
  function populateUserTable() {
    const userTableBody = document.getElementById("userTableBody");
    const users = getRegisteredUsers();

    // Clear existing table rows
    userTableBody.innerHTML = "";

    // Loop through the registered users and create table rows
    for (const user of users) {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${user.Username}</td>
        <td>${user.Email}</td>
        <td>
          <button onclick="editUser('${user.Email}', '${user.Username}')">Edit</button>
          <button class="delete-button" data-email="${user.Email}">Delete</button>

        </td>
      `;
      document.getElementById("userTableBody").addEventListener("click", function(event) {
        if (event.target.tagName === "BUTTON" && event.target.classList.contains("delete-button")) {
          const email = event.target.dataset.email;
          openDeleteModal(email);
        }
      });
      
      userTableBody.appendChild(row);
    }
  }

  // Call the function to populate the table
  populateUserTable();
});
