// Function to display messages sent by the user
function displayUserMessages() {
  const chatBox = document.getElementById("chat-box");
  chatBox.innerHTML = ""; // Clear the chat box

  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    const message = localStorage.getItem(key);

    // Check if the message was sent by the user (using a specific prefix, e.g., "user:")
    if (key.startsWith("user:")) {
      const messageElement = document.createElement("div");
      messageElement.textContent = message;

      chatBox.appendChild(messageElement);
    }
  }
}

// Function to send a message and store it in local storage
function sendMessage() {
  const messageInput = document.getElementById("message-input");
  const message = messageInput.value;

  if (message.trim() !== "") {
    const timestamp = new Date().getTime();
    const userMessageKey = `user:${timestamp}`; // Use a specific prefix for user messages
    localStorage.setItem(userMessageKey, message);
    messageInput.value = ""; // Clear the input field
    displayUserMessages(); // Display updated user messages
  }
}

// Display user messages when the page loads
displayUserMessages();

// Add event listener to the send button
document.getElementById("send-button").addEventListener("click", sendMessage);

// Add event listener to the refresh button
document
  .getElementById("refresh-button")
  .addEventListener("click", displayUserMessages);
