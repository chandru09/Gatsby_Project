// Function to check if the provided username and password exist in local storage
function checkLogin(email, password) {
  const storedUsers = JSON.parse(localStorage.getItem("Users")) || [];
  //   console.log("Stored Users", storedUsers);
  const user = storedUsers.find(
    (u) => u.Email === email && u.Password === password
  );

  return user;
}
document.addEventListener("DOMContentLoaded", () => {
  // Function to handle form submission
  document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent the default form submission behavior

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Check if the provided email and password exist in local storage
    var user = checkLogin(email, password);

    if (user) {
      //alert("Login successful!"); // redirect the user to another page here
      localStorage.setItem("loggedInUser", JSON.stringify(user));
      window.location.href = "/html/loginSuccess.html";
    } else {
      //alert("Login Notsuccess!");
      if (email === "" || password === "") {
        // alert("Please fill in all fields.");
        document.getElementById("errors").innerHTML =
          "Please fill in all fields.";
        return false;
      }

      document.getElementById("errors").textContent =
        "Invalid email or password.";
    }
  });
});
