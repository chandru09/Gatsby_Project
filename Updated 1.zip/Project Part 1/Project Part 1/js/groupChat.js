document.addEventListener("DOMContentLoaded", function () {
  const chatBox = document.getElementById("chat-box");
  const messageInput = document.getElementById("message-input");
  const userChatName = document.getElementById("userChatName");
  const sendButton = document.getElementById("send-button");
  const refreshButton = document.getElementById("refresh-button");

  const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));

  function displayUserMessages() {
    chatBox.innerHTML = ""; // Clear the chat box

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      const message = localStorage.getItem(key);

      if (key.startsWith("user:")) {
        const messageParts = message.split(": ");
        if (messageParts.length >= 2) {
          const timestamp = messageParts[0].match(/\((.*?)\)/)[1];
          const nameAndMessage = messageParts.slice(1).join("- ");
          const [name, messageContent] = nameAndMessage.split("- ");
          console.log("Name", nameAndMessage);
          const messageElement = createMessageElement(
            name,
            timestamp,
            messageContent
          );
          chatBox.appendChild(messageElement);
        }
      }
    }
  }

  function sendMessage() {
    const message = messageInput.value.trim();
    if (message) {
      const timestamp = new Date().toLocaleString();
      const userMessageKey = `user:${timestamp}`;
      const fullMessage = `(${timestamp}): ${loggedInUser.Username}: ${message}`;
      localStorage.setItem(userMessageKey, fullMessage);
      messageInput.value = "";
      displayUserMessages();
    }
  }

  function createMessageElement(name, timestamp, messageContent) {
    const messageElement = document.createElement("div");
    messageElement.classList.add("message");

    const nameElement = document.createElement("strong");
    nameElement.textContent = name;

    const timestampElement = document.createElement("span");
    timestampElement.textContent = ` (${timestamp})`;

    const messageContentElement = document.createElement("span");
    messageContentElement.textContent = messageContent;

    messageElement.appendChild(nameElement);
    messageElement.appendChild(timestampElement);
    messageElement.appendChild(messageContentElement);

    return messageElement;
  }

  userChatName.textContent = loggedInUser.Username;
  displayUserMessages();

  sendButton.addEventListener("click", sendMessage);
  refreshButton.addEventListener("click", displayUserMessages);
});
