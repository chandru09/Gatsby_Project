document.addEventListener("DOMContentLoaded", function () {
  const loginUsers = localStorage.getItem("loggedInUser");
  const userEmail = JSON.parse(loginUsers);
  const result = userEmail.Email;
  if (result) {
    window.parent.document.getElementById("userEmail").textContent = result;
  } else {
    // If the email is not found in local storage, redirect to the login page
    window.location.href = "login.html";
  }
});
