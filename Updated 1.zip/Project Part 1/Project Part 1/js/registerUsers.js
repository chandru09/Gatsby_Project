document.addEventListener("DOMContentLoaded", () => {
  let form = document.getElementById("form");

  form.addEventListener("submit", (e) => {
    e.preventDefault(); // Prevent the default form submission behavior
    if (validateForm()) {
      var users = JSON.parse(localStorage.getItem("Users")) || [];
      console.log("Users", users);
      var userData = {
        Username: document.getElementById("fullName").value,
        Email: document.getElementById("email").value,
        Password: document.getElementById("password").value,
        ConfirmPassword: document.getElementById("confirmPassword").value,
      };

      users.push(userData);
      localStorage.setItem("Users", JSON.stringify(users));

      // Clear the form fields after submission
      window.location.href = "/html/registerSuccess.html";
    }
  });
});

function validateForm() {
  //alert("Validate");
  const fullName = document.getElementById("fullName").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;

  // Perform your validation checks here
  if (
    fullName === "" ||
    email === "" ||
    password === "" ||
    confirmPassword === ""
  ) {
    //alert("Please fill in all fields.");
    document.getElementById("errors").innerHTML = "Please fill in all fields.";
    return false;
  }

  if (password !== confirmPassword) {
    //alert("Passwords do not match.");
    document.getElementById("errors").innerHTML = "Passwords should be same";

    return false;
  }

  return true; // Form is valid
}
