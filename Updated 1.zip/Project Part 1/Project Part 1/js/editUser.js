// Function to retrieve a query string parameter from the URL
function getQueryStringParameter(name) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(name);
}

// Function to retrieve user data from local storage by email
function getUserDataByEmail(email) {
  const users = JSON.parse(localStorage.getItem("Users")) || [];
  return users.find((user) => user.Email === email);
}
function editUser(email, username) {
  // Redirect to the edit page with email and username as query parameters
  window.location.href = `editUser.html?email=${email}&username=${username}`;
}
// Function to update user data in local storage by email
function updateUserByEmail(email, fullName, updatedEmail) {
  const users = JSON.parse(localStorage.getItem("Users")) || [];
  console.log("users from local", users);
  const updatedUsers = users.map((user) => {
    if (user.Email === email) {
      user.Username = fullName;
      user.Email = updatedEmail;
    }
    return user;
  });
  console.log("updated", updatedUsers);
  localStorage.setItem("Users", JSON.stringify(updatedUsers));
  return true;
}

// Function to populate the edit form with user data
function populateEditForm() {
  const editFullName = document.getElementById("editFullName");
  const editEmail = document.getElementById("editEmail");

  // Get the user's email from the URL query string
  const userEmail = getQueryStringParameter("email");

  // Retrieve user data from local storage
  const userData = getUserDataByEmail(userEmail);

  // Populate the edit form with user data
  if (userData) {
    editFullName.value = userData.Username;
    editEmail.value = userData.Email;
  } else {
    alert("User not found.");
    // Redirect to another page or take appropriate action
  }
}

// Function to handle form submission for saving changes
document.addEventListener("DOMContentLoaded", () => {
  document
    .getElementById("editUserForm")
    .addEventListener("submit", function (e) {
      e.preventDefault();

      const editFullName = document.getElementById("editFullName").value;
      const editEmail = document.getElementById("editEmail").value;
      const userEmail = getQueryStringParameter("email");
      console.log("up", editFullName, editEmail, userEmail);
      const updated = updateUserByEmail(userEmail, editFullName, editEmail);

      if (updated) {
        alert("Changes saved successfully!");
        // Redirect to the user list or another page
        window.location.href = "/html/manageUser.html";
      } else {
        alert("Failed to save changes.");
      }
    });

  // Call the function to populate the edit form with user data
  populateEditForm();
});
